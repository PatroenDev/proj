<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ServerController;
use App\Http\Controllers\VoteController; // Add VoteController import
use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Admin\SiteSettingsController;
use App\Http\Controllers\Admin\BannerController;
use App\Http\Controllers\Admin\ServerManagementController;
use App\Http\Controllers\Admin\UserManagementController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Public Routes
Route::get("/", [ServerController::class, "index"])->name("home"); // Use ServerController for home
Route::get("/servers/{server}", [ServerController::class, "show"])->name("servers.show");

// Breeze Dashboard (likely unused if we have a custom home)
Route::get("/dashboard", function () {
    // Redirect to home or user's servers page instead?
    return redirect()->route("home");
})->middleware(["auth", "verified"])->name("dashboard");

// Authenticated User Routes
Route::middleware(["auth", "verified"])->group(function () {
    // Profile
    Route::get("/profile", [ProfileController::class, "edit"])->name("profile.edit");
    Route::patch("/profile", [ProfileController::class, "update"])->name("profile.update");
    Route::delete("/profile", [ProfileController::class, "destroy"])->name("profile.destroy");

    // User's Servers Management
    Route::get("/my-servers", function () { // Replace with controller method later if needed
        $servers = auth()->user()->servers()->latest()->paginate(10);
        return view("profile.servers", compact("servers"));
    })->name("profile.servers");
    Route::get("/servers/create", [ServerController::class, "create"])->name("servers.create");
    Route::post("/servers", [ServerController::class, "store"])->name("servers.store");
    Route::get("/servers/{server}/edit", [ServerController::class, "edit"])->name("servers.edit");
    Route::put("/servers/{server}", [ServerController::class, "update"])->name("servers.update");
    Route::delete("/servers/{server}", [ServerController::class, "destroy"])->name("servers.destroy");

    // Voting
    Route::post("/servers/{server}/vote", [VoteController::class, "store"])->name("servers.vote");
});

// Admin Routes
Route::middleware(["auth", "admin"])->prefix("admin")->name("admin.")->group(function () {
    Route::get("/dashboard", [AdminDashboardController::class, "index"])->name("dashboard");

    // Site Settings Routes
    Route::get("/settings", [SiteSettingsController::class, "index"])->name("settings.index");
    Route::post("/settings", [SiteSettingsController::class, "update"])->name("settings.update");

    // Banner Management Routes
    Route::resource("banners", BannerController::class);

    // Server Management Routes
    Route::patch("servers/{server}/approve", [ServerManagementController::class, "approve"])->name("servers.approve");
    Route::resource("servers", ServerManagementController::class)->except(["create", "store"]);

    // User Management Routes
    // Route::patch("users/{user}/ban", [UserManagementController::class, "ban"])->name("users.ban");
    Route::resource("users", UserManagementController::class)->except(["create", "store"]);
});


require __DIR__."/auth.php";

// Remove the temporary home view creation if ServerController@index handles it
// if (!file_exists(resource_path("views/home.blade.php"))) { ... }


