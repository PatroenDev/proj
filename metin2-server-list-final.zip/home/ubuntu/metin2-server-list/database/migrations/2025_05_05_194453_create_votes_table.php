<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create("votes", function (Blueprint $table) {
            $table->id();
            $table->foreignId("user_id")->constrained()->onDelete("cascade");
            $table->foreignId("server_id")->constrained()->onDelete("cascade");
            $table->date("voted_date"); // Store the date of the vote to check daily limit
            $table->timestamps(); // Includes created_at which can represent the exact time of vote

            // Unique constraint to prevent a user from voting for the same server more than once per day
            $table->unique(["user_id", "server_id", "voted_date"]);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists("votes");
    }
};

