<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * Bu migrasyon, 'votes' tablosuna IP adresi takibi için 'ip_address' sütununu ekler.
     */
    public function up(): void
    {
        Schema::table('votes', function (Blueprint $table) {
            // IP adresini saklamak için nullable bir string sütun ekleniyor.
            // Nullable olmasının sebebi, eski oylarda bu bilginin olmaması olabilir veya bazı durumlarda IP alınamayabilir.
            $table->ipAddress('ip_address')->nullable()->after('server_id');
        });
    }

    /**
     * Reverse the migrations.
     * Bu metod, 'up' metodunda yapılan değişiklikleri geri alır, yani 'ip_address' sütununu kaldırır.
     */
    public function down(): void
    {
        Schema::table('votes', function (Blueprint $table) {
            // 'ip_address' sütununu kaldırır.
            $table->dropColumn('ip_address');
        });
    }
};

