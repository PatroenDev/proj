<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * Bu migrasyon, 'users' tablosuna kullanıcıları yasaklamak için 'is_banned' sütununu ekler.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Kullanıcının yasaklı olup olmadığını belirten boolean bir sütun ekleniyor.
            // Varsayılan olarak false (yasaklı değil).
            // 'is_admin' sütunundan sonra ekleniyor.
            $table->boolean('is_banned')->default(false)->after('is_admin');
        });
    }

    /**
     * Reverse the migrations.
     * Bu metod, 'up' metodunda yapılan değişiklikleri geri alır, yani 'is_banned' sütununu kaldırır.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // 'is_banned' sütununu kaldırır.
            $table->dropColumn('is_banned');
        });
    }
};

