<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create("servers", function (Blueprint $table) {
            $table->id();
            $table->foreignId("user_id")->constrained()->onDelete("cascade"); // Link to the user who added the server
            $table->string("name");
            $table->string("short_desc");
            $table->enum("category", ["Orta", "Emek", "Wslik", "Oldschool"]);
            $table->integer("start_level")->default(1);
            $table->integer("end_level")->default(99);
            $table->text("features")->nullable();
            $table->date("opening_date")->nullable();
            $table->string("site_link")->nullable();
            $table->string("discord_link")->nullable();
            $table->string("cover_image_path")->nullable();
            $table->boolean("is_approved")->default(false); // Admin approval status
            $table->boolean("is_vip")->default(false);
            $table->timestamp("vip_expires_at")->nullable();
            $table->unsignedBigInteger("vote_count")->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists("servers");
    }
};

