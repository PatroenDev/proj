<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __("Sunucularım") }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    {{ __("Burada eklediğiniz sunucular listelenecek.") }}
                    {{-- Server listing logic will be added here later --}}
                    {{-- @foreach ($servers as $server)
                        <div class="mb-4 p-4 border dark:border-gray-700 rounded">
                            <h3 class="text-lg font-semibold">{{ $server->name }}</h3>
                            <p>{{ $server->short_desc }}</p>
                            <p>Kategori: {{ $server->category }}</p>
                            <a href="#" class="text-blue-500 hover:underline">Düzenle</a>
                            <form action="#" method="POST" class="inline">
                                @csrf
                                @method("DELETE")
                                <button type="submit" class="text-red-500 hover:underline ml-2">Sil</button>
                            </form>
                        </div>
                    @endforeach --}}
                </div>
            </div>
        </div>
    </div>
</x-app-layout>

