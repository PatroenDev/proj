<!-- Sidebar -->
<div
    class="fixed inset-y-0 left-0 z-30 w-64 overflow-y-auto transition duration-300 transform bg-gray-900 lg:translate-x-0 lg:static lg:inset-0"
    :class="{ 	'translate-x-0 ease-out': sidebarOpen, 	'-translate-x-full ease-in': !sidebarOpen }"
>
    <div class="flex items-center justify-center mt-8">
        <div class="flex items-center">
            {{-- <x-application-logo class="block h-12 w-auto" /> --}}
            <span class="text-white text-2xl mx-2 font-semibold">Admin Paneli</span>
        </div>
    </div>

    <nav class="mt-10">
        <a
            class="flex items-center px-6 py-2 mt-4 duration-200 border-l-4"
            :class="[request()->routeIs("admin.dashboard") ? "bg-gray-600 border-gray-100 text-gray-100" : "border-gray-900 text-gray-500 hover:bg-gray-600 hover:bg-opacity-25 hover:text-gray-100"]"
            href="{{ route("admin.dashboard") }}" {{-- Assuming admin.dashboard route --}}
        >
            {{-- Add Dashboard Icon --}}
            <span class="mx-4">Kontrol Paneli</span>
        </a>

        <a
            class="flex items-center px-6 py-2 mt-4 duration-200 border-l-4"
            :class="[request()->routeIs("admin.settings.*") ? "bg-gray-600 border-gray-100 text-gray-100" : "border-gray-900 text-gray-500 hover:bg-gray-600 hover:bg-opacity-25 hover:text-gray-100"]"
            href="#" {{-- Placeholder for settings route --}}
        >
             {{-- Add Settings Icon --}}
            <span class="mx-4">Site Ayarları</span>
        </a>

        <a
            class="flex items-center px-6 py-2 mt-4 duration-200 border-l-4"
            :class="[request()->routeIs("admin.banners.*") ? "bg-gray-600 border-gray-100 text-gray-100" : "border-gray-900 text-gray-500 hover:bg-gray-600 hover:bg-opacity-25 hover:text-gray-100"]"
            href="#" {{-- Placeholder for banners route --}}
        >
             {{-- Add Banner Icon --}}
            <span class="mx-4">Banner Yönetimi</span>
        </a>

        <a
            class="flex items-center px-6 py-2 mt-4 duration-200 border-l-4"
            :class="[request()->routeIs("admin.servers.*") ? "bg-gray-600 border-gray-100 text-gray-100" : "border-gray-900 text-gray-500 hover:bg-gray-600 hover:bg-opacity-25 hover:text-gray-100"]"
            href="#" {{-- Placeholder for servers route --}}
        >
             {{-- Add Server Icon --}}
            <span class="mx-4">Sunucu Yönetimi</span>
        </a>

        <a
            class="flex items-center px-6 py-2 mt-4 duration-200 border-l-4"
            :class="[request()->routeIs("admin.users.*") ? "bg-gray-600 border-gray-100 text-gray-100" : "border-gray-900 text-gray-500 hover:bg-gray-600 hover:bg-opacity-25 hover:text-gray-100"]"
            href="#" {{-- Placeholder for users route --}}
        >
             {{-- Add User Icon --}}
            <span class="mx-4">Kullanıcı Yönetimi</span>
        </a>

    </nav>
</div>

