<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __("Yeni Banner Ekle") }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <form method="POST" action="{{ route("admin.banners.store") }}" enctype="multipart/form-data">
                        @csrf

                        <!-- Image -->
                        <div class="mb-4">
                            <x-input-label for="image" :value="__("Banner Görseli")" />
                            <input id="image" name="image" type="file" class="block w-full text-sm text-gray-500 dark:text-gray-400
                                file:me-4 file:py-2 file:px-4
                                file:rounded-lg file:border-0
                                file:text-sm file:font-semibold
                                file:bg-custom-red file:text-white
                                hover:file:bg-red-700
                                file:disabled:opacity-50 file:disabled:pointer-events-none
                                dark:file:bg-red-700
                                dark:hover:file:bg-red-600
                            " required>
                            <x-input-error :messages="$errors->get("image")" class="mt-2" />
                            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">PNG, JPG, GIF, SVG (Max 2MB).</p>
                        </div>

                        <!-- Link -->
                        <div class="mb-4">
                            <x-input-label for="link" :value="__("Link (Opsiyonel)")" />
                            <x-text-input id="link" class="block mt-1 w-full dark:bg-gray-700 dark:text-white" type="url" name="link" :value="old("link")" placeholder="https://example.com" />
                            <x-input-error :messages="$errors->get("link")" class="mt-2" />
                        </div>

                        <!-- Position -->
                        <div class="mb-4">
                            <x-input-label for="position" :value="__("Pozisyon")" />
                            <select id="position" name="position" class="block mt-1 w-full border-gray-300 dark:border-gray-700 dark:bg-gray-700 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm" required>
                                <option value="top" {{ old("position") == "top" ? "selected" : "" }}>Üst</option>
                                <option value="left" {{ old("position") == "left" ? "selected" : "" }}>Sol</option>
                                <option value="right" {{ old("position") == "right" ? "selected" : "" }}>Sağ</option>
                            </select>
                            <x-input-error :messages="$errors->get("position")" class="mt-2" />
                        </div>

                        <!-- Expires At -->
                        <div class="mb-4">
                            <x-input-label for="expires_at" :value="__("Bitiş Tarihi (Opsiyonel)")" />
                            <x-text-input id="expires_at" class="block mt-1 w-full dark:bg-gray-700 dark:text-white" type="datetime-local" name="expires_at" :value="old("expires_at")" />
                            <x-input-error :messages="$errors->get("expires_at")" class="mt-2" />
                            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Bu tarihi boş bırakırsanız banner süresiz olarak gösterilir.</p>
                        </div>

                        <div class="flex items-center justify-end mt-6">
                             <a href="{{ route("admin.banners.index") }}" class="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-md text-sm font-medium mr-2">
                                İptal
                            </a>
                            <x-primary-button class="bg-custom-red hover:bg-red-700 focus:bg-red-700 active:bg-red-800 focus:ring-red-500">
                                {{ __("Banner Ekle") }}
                            </x-primary-button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-admin-layout>

