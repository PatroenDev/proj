<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __("Kullanıcı Düzenle: ") . $user->name }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <form method="POST" action="{{ route("admin.users.update", $user) }}">
                        @csrf
                        @method("PUT")

                        <!-- User Name (Readonly) -->
                        <div class="mb-4">
                            <x-input-label for="name" :value="__("Kullanıcı Adı")" />
                            <x-text-input id="name" class="block mt-1 w-full bg-gray-100 dark:bg-gray-700 dark:text-gray-400" type="text" name="name" :value="$user->name" readonly disabled />
                        </div>

                        <!-- Email (Readonly) -->
                        <div class="mb-4">
                            <x-input-label for="email" :value="__("Email")" />
                            <x-text-input id="email" class="block mt-1 w-full bg-gray-100 dark:bg-gray-700 dark:text-gray-400" type="email" name="email" :value="$user->email" readonly disabled />
                        </div>

                        <!-- Is Admin -->
                        <div class="mb-4">
                            <label for="is_admin" class="inline-flex items-center">
                                {{-- Prevent unmaking the first user admin --}}
                                <input id="is_admin" type="checkbox" class="rounded dark:bg-gray-900 border-gray-300 dark:border-gray-700 text-indigo-600 shadow-sm focus:ring-indigo-500 dark:focus:ring-indigo-600 dark:focus:ring-offset-gray-800" name="is_admin" value="1" {{ old("is_admin", $user->is_admin) ? "checked" : "" }} {{ $user->id === 1 ? "disabled" : "" }}>
                                <span class="ms-2 text-sm text-gray-600 dark:text-gray-400">{{ __("Admin Yetkisi Ver") }}</span>
                            </label>
                             @if($user->id === 1)
                                <p class="mt-1 text-sm text-yellow-600 dark:text-yellow-400">İlk kullanıcının admin yetkisi kaldırılamaz.</p>
                            @endif
                            <x-input-error :messages="$errors->get("is_admin")" class="mt-2" />
                        </div>

                        {{-- Ban Status (Optional Feature) --}}
                        {{-- <div class="mb-4">
                            <label for="is_banned" class="inline-flex items-center">
                                <input id="is_banned" type="checkbox" class="rounded dark:bg-gray-900 border-gray-300 dark:border-gray-700 text-red-600 shadow-sm focus:ring-red-500 dark:focus:ring-red-600 dark:focus:ring-offset-gray-800" name="is_banned" value="1" {{ old("is_banned", $user->is_banned ?? false) ? "checked" : "" }} {{ Auth::id() === $user->id || $user->id === 1 ? "disabled" : "" }}>
                                <span class="ms-2 text-sm text-gray-600 dark:text-gray-400">{{ __("Kullanıcıyı Banla") }}</span>
                            </label>
                             @if(Auth::id() === $user->id || $user->id === 1)
                                <p class="mt-1 text-sm text-yellow-600 dark:text-yellow-400">Kendinizi veya ilk kullanıcıyı banlayamazsınız.</p>
                            @endif
                            <x-input-error :messages="$errors->get("is_banned")" class="mt-2" />
                        </div> --}}

                        <div class="flex items-center justify-end mt-6">
                            <a href="{{ route("admin.users.index") }}" class="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-md text-sm font-medium mr-2">
                                İptal
                            </a>
                            <x-primary-button class="bg-custom-red hover:bg-red-700 focus:bg-red-700 active:bg-red-800 focus:ring-red-500">
                                {{ __("Kullanıcıyı Güncelle") }}
                            </x-primary-button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-admin-layout>

