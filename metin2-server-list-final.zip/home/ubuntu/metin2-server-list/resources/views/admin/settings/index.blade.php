<x-admin-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __("Site Ayarları") }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <form method="POST" action="{{ route("admin.settings.update") }}" enctype="multipart/form-data">
                        @csrf
                        {{-- @method("PATCH") or @method("PUT") if using resource controller --}}

                        <!-- Site Name -->
                        <div class="mb-4">
                            <x-input-label for="site_name" :value="__("Site Adı")" />
                            <x-text-input id="site_name" class="block mt-1 w-full dark:bg-gray-700 dark:text-white" type="text" name="site_name" :value="old("site_name", $settings["site_name"] ?? "")" required autofocus />
                            <x-input-error :messages="$errors->get("site_name")" class="mt-2" />
                        </div>

                        <!-- Site Description -->
                        <div class="mb-4">
                            <x-input-label for="site_description" :value="__("Site Açıklaması")" />
                            <textarea id="site_description" name="site_description" rows="3" class="block mt-1 w-full border-gray-300 dark:border-gray-700 dark:bg-gray-700 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">{{ old("site_description", $settings["site_description"] ?? "") }}</textarea>
                            <x-input-error :messages="$errors->get("site_description")" class="mt-2" />
                        </div>

                        <!-- Logo -->
                        <div class="mb-4">
                            <x-input-label for="logo" :value="__("Logo")" />
                            @if (!empty($settings["logo_path"]))
                                <div class="mt-2 mb-2">
                                    <img src="{{ Storage::url($settings["logo_path"]) }}" alt="Mevcut Logo" class="h-16 object-contain">
                                </div>
                            @endif
                            <input id="logo" name="logo" type="file" class="block w-full text-sm text-gray-500 dark:text-gray-400
                                file:me-4 file:py-2 file:px-4
                                file:rounded-lg file:border-0
                                file:text-sm file:font-semibold
                                file:bg-custom-red file:text-white
                                hover:file:bg-red-700
                                file:disabled:opacity-50 file:disabled:pointer-events-none
                                dark:file:bg-red-700
                                dark:hover:file:bg-red-600
                            ">
                            <x-input-error :messages="$errors->get("logo")" class="mt-2" />
                            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">PNG, JPG, GIF, SVG (Max 2MB).</p>
                        </div>

                        <!-- Favicon -->
                        <div class="mb-4">
                            <x-input-label for="favicon" :value="__("Favicon")" />
                             @if (!empty($settings["favicon_path"]))
                                <div class="mt-2 mb-2">
                                    <img src="{{ Storage::url($settings["favicon_path"]) }}" alt="Mevcut Favicon" class="h-8 w-8 object-contain">
                                </div>
                            @endif
                            <input id="favicon" name="favicon" type="file" class="block w-full text-sm text-gray-500 dark:text-gray-400
                                file:me-4 file:py-2 file:px-4
                                file:rounded-lg file:border-0
                                file:text-sm file:font-semibold
                                file:bg-custom-red file:text-white
                                hover:file:bg-red-700
                                file:disabled:opacity-50 file:disabled:pointer-events-none
                                dark:file:bg-red-700
                                dark:hover:file:bg-red-600
                            ">
                            <x-input-error :messages="$errors->get("favicon")" class="mt-2" />
                             <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">ICO, PNG (Max 512KB).</p>
                        </div>

                        <div class="flex items-center justify-end mt-6">
                            <x-primary-button class="bg-custom-red hover:bg-red-700 focus:bg-red-700 active:bg-red-800 focus:ring-red-500">
                                {{ __("Ayarları Kaydet") }}
                            </x-primary-button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-admin-layout>

