<div
    x-show="loginModalOpen"
    x-transition:enter="ease-out duration-300"
    x-transition:enter-start="opacity-0"
    x-transition:enter-end="opacity-100"
    x-transition:leave="ease-in duration-200"
    x-transition:leave-start="opacity-100"
    x-transition:leave-end="opacity-0"
    class="fixed inset-0 z-50 flex items-center justify-center bg-gray-900 bg-opacity-75"
    style="display: none;" {{-- Initially hidden --}}
    @keydown.escape.window="loginModalOpen = false"
>
    <div
        x-show="loginModalOpen"
        x-transition:enter="ease-out duration-300"
        x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
        x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
        x-transition:leave="ease-in duration-200"
        x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100"
        x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
        class="relative w-full max-w-md p-6 mx-auto bg-gray-800 rounded-lg shadow-xl"
        @click.away="loginModalOpen = false"
    >
        <button @click="loginModalOpen = false" class="absolute top-0 right-0 mt-4 mr-4 text-gray-400 hover:text-gray-200">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
        </button>

        <h2 class="text-2xl font-semibold text-center text-white mb-6">{{ __("Giriş Yap") }}</h2>

        <!-- Session Status -->
        <x-auth-session-status class="mb-4" :status="session("status")" />

        <form method="POST" action="{{ route("login") }}">
            @csrf

            <!-- Email Address -->
            <div>
                <x-input-label for="email_login" :value="__("E-posta")" class="text-gray-300"/>
                <x-text-input id="email_login" class="block mt-1 w-full bg-gray-700 border-gray-600 text-white focus:border-red-500 focus:ring-red-500" type="email" name="email" :value="old("email")" required autofocus autocomplete="username" />
                <x-input-error :messages="$errors->get("email")" class="mt-2" />
            </div>

            <!-- Password -->
            <div class="mt-4">
                <x-input-label for="password_login" :value="__("Şifre")" class="text-gray-300"/>
                <x-text-input id="password_login" class="block mt-1 w-full bg-gray-700 border-gray-600 text-white focus:border-red-500 focus:ring-red-500" type="password" name="password" required autocomplete="current-password" />
                <x-input-error :messages="$errors->get("password")" class="mt-2" />
            </div>

            <!-- Remember Me -->
            <div class="block mt-4">
                <label for="remember_me_login" class="inline-flex items-center">
                    <input id="remember_me_login" type="checkbox" class="rounded dark:bg-gray-900 border-gray-300 dark:border-gray-700 text-custom-red shadow-sm focus:ring-custom-red dark:focus:ring-custom-red dark:focus:ring-offset-gray-800" name="remember">
                    <span class="ms-2 text-sm text-gray-400">{{ __("Beni Hatırla") }}</span>
                </label>
            </div>

            <div class="flex items-center justify-end mt-4">
                @if (Route::has("password.request"))
                    <a class="underline text-sm text-gray-400 hover:text-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800" href="{{ route("password.request") }}">
                        {{ __("Şifreni mi unuttun?") }}
                    </a>
                @endif

                <x-primary-button class="ms-3 bg-custom-red hover:bg-red-700 focus:bg-red-700 active:bg-red-800 focus:ring-red-500">
                    {{ __("Giriş Yap") }}
                </x-primary-button>
            </div>
        </form>
    </div>
</div>

