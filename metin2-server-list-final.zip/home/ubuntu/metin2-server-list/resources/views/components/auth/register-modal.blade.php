<div
    x-show="registerModalOpen"
    x-transition:enter="ease-out duration-300"
    x-transition:enter-start="opacity-0"
    x-transition:enter-end="opacity-100"
    x-transition:leave="ease-in duration-200"
    x-transition:leave-start="opacity-100"
    x-transition:leave-end="opacity-0"
    class="fixed inset-0 z-50 flex items-center justify-center bg-gray-900 bg-opacity-75"
    style="display: none;" {{-- Initially hidden --}}
    @keydown.escape.window="registerModalOpen = false"
>
    <div
        x-show="registerModalOpen"
        x-transition:enter="ease-out duration-300"
        x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
        x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
        x-transition:leave="ease-in duration-200"
        x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100"
        x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
        class="relative w-full max-w-md p-6 mx-auto bg-gray-800 rounded-lg shadow-xl"
        @click.away="registerModalOpen = false"
    >
        <button @click="registerModalOpen = false" class="absolute top-0 right-0 mt-4 mr-4 text-gray-400 hover:text-gray-200">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
        </button>

        <h2 class="text-2xl font-semibold text-center text-white mb-6">{{ __("Kayıt Ol") }}</h2>

        <form method="POST" action="{{ route("register") }}">
            @csrf

            <!-- Name -->
            <div>
                <x-input-label for="name_register" :value="__("Kullanıcı Adı")" class="text-gray-300" />
                <x-text-input id="name_register" class="block mt-1 w-full bg-gray-700 border-gray-600 text-white focus:border-red-500 focus:ring-red-500" type="text" name="name" :value="old("name")" required autofocus autocomplete="name" />
                <x-input-error :messages="$errors->get("name")" class="mt-2" />
            </div>

            <!-- Email Address -->
            <div class="mt-4">
                <x-input-label for="email_register" :value="__("E-posta")" class="text-gray-300" />
                <x-text-input id="email_register" class="block mt-1 w-full bg-gray-700 border-gray-600 text-white focus:border-red-500 focus:ring-red-500" type="email" name="email" :value="old("email")" required autocomplete="username" />
                <x-input-error :messages="$errors->get("email")" class="mt-2" />
            </div>

            <!-- Password -->
            <div class="mt-4">
                <x-input-label for="password_register" :value="__("Şifre")" class="text-gray-300" />
                <x-text-input id="password_register" class="block mt-1 w-full bg-gray-700 border-gray-600 text-white focus:border-red-500 focus:ring-red-500" type="password" name="password" required autocomplete="new-password" />
                <x-input-error :messages="$errors->get("password")" class="mt-2" />
            </div>

            <!-- Confirm Password -->
            <div class="mt-4">
                <x-input-label for="password_confirmation_register" :value="__("Şifreyi Onayla")" class="text-gray-300" />
                <x-text-input id="password_confirmation_register" class="block mt-1 w-full bg-gray-700 border-gray-600 text-white focus:border-red-500 focus:ring-red-500" type="password" name="password_confirmation" required autocomplete="new-password" />
                <x-input-error :messages="$errors->get("password_confirmation")" class="mt-2" />
            </div>

            <div class="flex items-center justify-end mt-4">
                <a class="underline text-sm text-gray-400 hover:text-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800" href="#" @click.prevent="loginModalOpen = true; registerModalOpen = false;">
                    {{ __("Zaten kayıtlı mısın?") }}
                </a>

                <x-primary-button class="ms-4 bg-custom-red hover:bg-red-700 focus:bg-red-700 active:bg-red-800 focus:ring-red-500">
                    {{ __("Kayıt Ol") }}
                </x-primary-button>
            </div>
        </form>
    </div>
</div>

