<x-app-layout>
    {{-- Optional Header --}}
    {{-- <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __("Metin2 Sunucu Listesi") }}
        </h2>
    </x-slot> --}}

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            {{-- Top Banner Alanı --}}
            @if(isset($topBanner) && $topBanner)
            <div class="mb-6">
                <a href="{{ $topBanner->link ?? '#' }}" target="_blank" rel="noopener noreferrer">
                    {{-- Storage::url public diskindeki dosyanın URL'sini oluşturur --}}
                    <img src="{{ Storage::url($topBanner->image_path) }}" alt="{{ $topBanner->name ?? 'Top Banner' }}" class="w-full h-auto object-contain rounded-lg shadow-md">
                </a>
            </div>
            @endif

            <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
                {{-- Sol Banner Alanı --}}
                @if(isset($leftBanners) && $leftBanners->isNotEmpty())
                <div class="hidden lg:block lg:col-span-1 space-y-4">
                    @foreach($leftBanners as $banner)
                        <a href="{{ $banner->link ?? '#' }}" target="_blank" rel="noopener noreferrer">
                            <img src="{{ Storage::url($banner->image_path) }}" alt="{{ $banner->name ?? 'Left Banner' }}" class="w-full h-auto object-contain rounded-lg shadow-md">
                        </a>
                    @endforeach
                </div>
                @else
                 {{-- Sol banner yoksa veya boşsa, ana içeriğin genişlemesi için yer tutucu --}}
                 <div class="hidden lg:block lg:col-span-1"></div>
                @endif

                {{-- Sunucu Listesi (Ana İçerik) - Sol/Sağ banner durumuna göre genişliği ayarla --}}
                <div class="lg:col-span-{{ (isset($leftBanners) && $leftBanners->isNotEmpty()) || (isset($rightBanners) && $rightBanners->isNotEmpty()) ? '2' : '4' }} space-y-4">
                    <h2 class="text-2xl font-semibold text-gray-800 dark:text-gray-200 mb-4">Sunucu Listesi</h2>

                    {{-- Filters (Placeholder) --}}
                    {{-- <div class="bg-white dark:bg-gray-800 p-4 rounded-lg shadow mb-4">
                        <p class="text-gray-600 dark:text-gray-400">Filtreleme seçenekleri buraya gelecek (Kategori, Durum vb.)</p>
                    </div> --}}

                    @forelse ($servers as $server)
                        {{-- VIP sunucular için daha belirgin stil --}}
                        <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg border-l-4 {{ $server->is_vip ? 'border-purple-600 border-l-8 shadow-lg ring-1 ring-purple-500/30 dark:bg-gray-800/90' : 'border-custom-red dark:bg-gray-800' }}">
                            <div class="p-4 md:p-6 flex flex-col md:flex-row items-start md:items-center">
                                {{-- Kapak Görseli --}}
                                <div class="w-full md:w-1/4 mb-4 md:mb-0 md:mr-6 flex-shrink-0">
                                    @if($server->cover_image_path)
                                        <img src="{{ Storage::url($server->cover_image_path) }}" alt="{{ $server->name }}" class="w-full h-32 object-cover rounded-md">
                                    @else
                                        <div class="w-full h-32 bg-gray-200 dark:bg-gray-700 rounded-md flex items-center justify-center">
                                            <span class="text-gray-500 dark:text-gray-400 text-sm">Görsel Yok</span>
                                        </div>
                                    @endif
                                </div>

                                {{-- Sunucu Bilgileri --}}
                                <div class="flex-grow">
                                    <div class="flex justify-between items-start mb-1">
                                        <h3 class="text-lg md:text-xl font-semibold text-gray-900 dark:text-gray-100">
                                            <a href="{{ route('servers.show', $server) }}" class="hover:text-custom-red dark:hover:text-red-400">{{ $server->name }}</a>
                                            @if($server->is_vip)
                                                <span class="ml-2 px-2 py-0.5 inline-flex text-xs leading-5 font-semibold rounded-full bg-purple-100 text-purple-800 dark:bg-purple-700 dark:text-purple-100">VIP</span>
                                            @endif
                                        </h3>
                                        <span class="text-sm text-gray-500 dark:text-gray-400 whitespace-nowrap ml-4">{{ $server->vote_count }} Oy</span>
                                    </div>
                                    <p class="text-sm text-gray-600 dark:text-gray-400 mb-2 line-clamp-2">{{ $server->short_desc }}</p>
                                    <div class="flex flex-wrap items-center text-xs text-gray-500 dark:text-gray-400 space-x-3">
                                        <span><span class="font-medium">Kategori:</span> {{ $server->category }}</span>
                                        <span><span class="font-medium">Seviye:</span> {{ $server->start_level }}-{{ $server->end_level }}</span>
                                        <span><span class="font-medium">Açılış:</span> {{ $server->opening_date->format('d.m.Y') }}</span>
                                    </div>
                                </div>

                                {{-- Eylem Butonları --}}
                                <div class="mt-4 md:mt-0 md:ml-6 flex flex-col space-y-2 items-stretch md:items-end flex-shrink-0">
                                    <a href="{{ route('servers.show', $server) }}" class="w-full md:w-auto text-center px-3 py-1.5 border border-transparent text-xs font-medium rounded shadow-sm text-white bg-custom-red hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 dark:focus:ring-offset-gray-800">
                                        Detaylar
                                    </a>
                                    {{-- Oy Verme Butonu (Form içine alınmalı) --}}
                                    <form action="{{ route('servers.vote', $server) }}" method="POST" class="w-full md:w-auto">
                                        @csrf
                                        <button type="submit" class="w-full text-center px-3 py-1.5 border border-transparent text-xs font-medium rounded shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 dark:focus:ring-offset-gray-800">
                                            Oy Ver
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                            <div class="p-6 text-gray-900 dark:text-gray-100 text-center">
                                Henüz onaylanmış sunucu bulunmuyor.
                            </div>
                        </div>
                    @endforelse

                    {{-- Sayfalama --}}
                    <div class="mt-6">
                        {{ $servers->links() }}
                    </div>
                </div>

                {{-- Sağ Banner Alanı --}}
                @if(isset($rightBanners) && $rightBanners->isNotEmpty())
                <div class="hidden lg:block lg:col-span-1 space-y-4">
                     @foreach($rightBanners as $banner)
                        <a href="{{ $banner->link ?? '#' }}" target="_blank" rel="noopener noreferrer">
                            <img src="{{ Storage::url($banner->image_path) }}" alt="{{ $banner->name ?? 'Right Banner' }}" class="w-full h-auto object-contain rounded-lg shadow-md">
                        </a>
                    @endforeach
                </div>
                @elseif(isset($leftBanners) && $leftBanners->isNotEmpty()) {{-- Eğer sol banner varsa ve sağ banner yoksa, hizalamayı korumak için boş bir sütun --}}
                 <div class="hidden lg:block lg:col-span-1"></div>
                @endif
            </div>
        </div>
    </div>
</x-app-layout>

