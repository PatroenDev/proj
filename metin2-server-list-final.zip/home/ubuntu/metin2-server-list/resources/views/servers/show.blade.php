<x-app-layout>
    <x-slot name="header">
        <h2 class="font-medievalsharp font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ $server->name }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800/90 overflow-hidden shadow-lg sm:rounded-lg border border-gray-200 dark:border-gray-700">
                <div class="p-6 text-gray-900 dark:text-gray-100">

                    {{-- Kapak Görseli --}}
                    @if($server->cover_image_path)
                        <img src="{{ Storage::url($server->cover_image_path) }}" alt="{{ $server->name }} Kapak Görseli" class="w-full h-64 object-cover rounded-lg mb-6 shadow-md">
                    @else
                        <div class="w-full h-64 bg-gray-200 dark:bg-gray-700 rounded-lg mb-6 flex items-center justify-center shadow-md">
                            <span class="text-gray-500 dark:text-gray-400">Kapak Görseli Yok</span>
                        </div>
                    @endif

                    {{-- Sunucu Detayları Grid --}}
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                        {{-- Sol Sütun (Detaylar) --}}
                        <div class="md:col-span-2 space-y-6">
                            <div>
                                <h3 class="text-lg font-semibold font-medievalsharp text-gray-900 dark:text-gray-100 border-b border-gray-300 dark:border-gray-600 pb-2 mb-2">Açıklama</h3>
                                <p class="mt-1 text-sm text-gray-600 dark:text-gray-300 whitespace-pre-line">{{ $server->short_desc }}</p>
                            </div>
                            <div>
                                <h3 class="text-lg font-semibold font-medievalsharp text-gray-900 dark:text-gray-100 border-b border-gray-300 dark:border-gray-600 pb-2 mb-2">Özellikler</h3>
                                <p class="mt-1 text-sm text-gray-600 dark:text-gray-300 whitespace-pre-line">{{ $server->features ?? "Belirtilmemiş" }}</p>
                            </div>
                             <div>
                                <h3 class="text-lg font-semibold font-medievalsharp text-gray-900 dark:text-gray-100 border-b border-gray-300 dark:border-gray-600 pb-2 mb-2">Sahip</h3>
                                <p class="mt-1 text-sm text-gray-600 dark:text-gray-300">{{ $server->user->name ?? "Bilinmiyor" }}</p>
                            </div>
                        </div>

                        {{-- Sağ Sütun (Bilgi Kutusu) --}}
                        <div class="space-y-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg border dark:border-gray-600 shadow">
                            <h3 class="text-lg font-semibold font-medievalsharp text-gray-900 dark:text-gray-100 border-b pb-2 dark:border-gray-600">Sunucu Bilgileri</h3>
                            <div class="flex justify-between text-sm">
                                <span class="font-medium text-gray-700 dark:text-gray-300">Kategori:</span>
                                <span class="text-gray-600 dark:text-gray-400">{{ $server->category }}</span>
                            </div>
                            <div class="flex justify-between text-sm">
                                <span class="font-medium text-gray-700 dark:text-gray-300">Seviye Aralığı:</span>
                                <span class="text-gray-600 dark:text-gray-400">{{ $server->start_level }} - {{ $server->end_level }}</span>
                            </div>
                            <div class="flex justify-between text-sm">
                                <span class="font-medium text-gray-700 dark:text-gray-300">Açılış Tarihi:</span>
                                <span class="text-gray-600 dark:text-gray-400">{{ $server->opening_date->format("d/m/Y") }}</span>
                            </div>
                            <div class="flex justify-between text-sm">
                                <span class="font-medium text-gray-700 dark:text-gray-300">Oylar:</span>
                                <span class="text-gray-600 dark:text-gray-400 font-bold">{{ $server->vote_count }}</span>
                            </div>
                            <div class="flex justify-between text-sm">
                                <span class="font-medium text-gray-700 dark:text-gray-300">Durum:</span>
                                @if($server->is_approved)
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-700 dark:text-green-100">Onaylı</span>
                                @else
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800 dark:bg-yellow-700 dark:text-yellow-100">Onay Bekliyor</span>
                                @endif
                            </div>
                             @if($server->is_vip)
                                <div class="flex justify-center text-sm mt-2">
                                    <span class="px-3 py-1 inline-flex text-sm leading-5 font-semibold rounded-full bg-purple-100 text-purple-800 dark:bg-purple-700 dark:text-purple-100 shadow">✨ VIP ✨</span>
                                </div>
                            @endif
                        </div>
                    </div>

                    {{-- Galeri Bölümü (Placeholder) --}}
                    <div class="mb-8">
                        <h3 class="text-lg font-semibold font-medievalsharp text-gray-900 dark:text-gray-100 border-b border-gray-300 dark:border-gray-600 pb-2 mb-4">Galeri</h3>
                        <div class="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg border dark:border-gray-600 text-center text-gray-500 dark:text-gray-400">
                            Sunucuya ait görseller buraya eklenecek (Geliştirme Gerekiyor).
                            {{-- Örnek Galeri Yapısı (Dinamik hale getirilmeli) --}}
                            {{-- <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <img src="..." alt="Galeri 1" class="rounded shadow">
                                <img src="..." alt="Galeri 2" class="rounded shadow">
                            </div> --}}
                        </div>
                    </div>

                    {{-- Yorumlar Bölümü (Placeholder) --}}
                    <div class="mb-6">
                        <h3 class="text-lg font-semibold font-medievalsharp text-gray-900 dark:text-gray-100 border-b border-gray-300 dark:border-gray-600 pb-2 mb-4">Yorumlar</h3>
                        <div class="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg border dark:border-gray-600 text-gray-500 dark:text-gray-400">
                            <p class="text-center mb-4">Kullanıcı yorumları ve yorum yapma formu buraya eklenecek (Geliştirme Gerekiyor).</p>
                            {{-- Örnek Yorum Yapısı (Dinamik hale getirilmeli) --}}
                            {{-- <div class="border-b dark:border-gray-600 py-3">
                                <p class="font-semibold">Kullanıcı Adı</p>
                                <p class="text-sm">Yorum içeriği...</p>
                            </div> --}}
                            {{-- Yorum Formu --}}
                            {{-- <form action="..." method="POST" class="mt-4">
                                @csrf
                                <textarea name="comment" class="..." placeholder="Yorumunuzu yazın..."></textarea>
                                <button type="submit" class="...">Gönder</button>
                            </form> --}}
                        </div>
                    </div>

                    {{-- Eylem Butonları --}}
                    <div class="flex flex-col sm:flex-row items-center justify-center space-y-3 sm:space-y-0 sm:space-x-4 mt-8 border-t pt-6 dark:border-gray-700">
                        <a href="{{ $server->site_link }}" target="_blank" rel="noopener noreferrer" class="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-custom-red hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 dark:focus:ring-offset-gray-800 transition duration-150">
                            Siteye Git
                        </a>
                        @if($server->discord_link)
                        <a href="{{ $server->discord_link }}" target="_blank" rel="noopener noreferrer" class="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3 border border-gray-300 dark:border-gray-600 text-base font-medium rounded-md shadow-sm text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800 transition duration-150">
                            Discord
                        </a>
                        @endif
                        {{-- Oy Verme Butonu (Form içine alındı) --}}
                        <form action="{{ route("servers.vote", $server) }}" method="POST" class="w-full sm:w-auto">
                            @csrf
                            <button type="submit" class="w-full inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 dark:focus:ring-offset-gray-800 transition duration-150">
                                Oy Ver ({{ $server->vote_count }})
                            </button>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</x-app-layout>

