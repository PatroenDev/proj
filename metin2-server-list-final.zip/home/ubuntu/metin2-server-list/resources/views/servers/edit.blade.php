<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __("Sunucuyu Düzenle: ") . $server->name }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 md:p-8 text-gray-900 dark:text-gray-100">
                    <form method="POST" action="{{ route("servers.update", $server) }}" enctype="multipart/form-data">
                        @csrf
                        @method("PUT")

                        <!-- Server Name -->
                        <div class="mb-4">
                            <x-input-label for="name" :value="__("Sunucu Adı")" />
                            <x-text-input id="name" class="block mt-1 w-full dark:bg-gray-700 dark:text-white" type="text" name="name" :value="old("name", $server->name)" required autofocus />
                            <x-input-error :messages="$errors->get("name")" class="mt-2" />
                        </div>

                        <!-- Short Description -->
                        <div class="mb-4">
                            <x-input-label for="short_desc" :value="__("Kısa Açıklama (Liste görünümü için)")" />
                            <textarea id="short_desc" name="short_desc" rows="3" class="block mt-1 w-full border-gray-300 dark:border-gray-700 dark:bg-gray-700 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm" required>{{ old("short_desc", $server->short_desc) }}</textarea>
                            <x-input-error :messages="$errors->get("short_desc")" class="mt-2" />
                        </div>

                        <!-- Category -->
                        <div class="mb-4">
                            <x-input-label for="category" :value="__("Kategori")" />
                            <select id="category" name="category" class="block mt-1 w-full border-gray-300 dark:border-gray-700 dark:bg-gray-700 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm" required>
                                @foreach(["Orta", "Emek", "Wslik", "Oldschool"] as $category)
                                    <option value="{{ $category }}" {{ old("category", $server->category) == $category ? "selected" : "" }}>{{ $category }}</option>
                                @endforeach
                            </select>
                            <x-input-error :messages="$errors->get("category")" class="mt-2" />
                        </div>

                        <!-- Level Range -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <x-input-label for="start_level" :value="__("Başlangıç Seviyesi")" />
                                <x-text-input id="start_level" class="block mt-1 w-full dark:bg-gray-700 dark:text-white" type="number" name="start_level" :value="old("start_level", $server->start_level)" required min="1" />
                                <x-input-error :messages="$errors->get("start_level")" class="mt-2" />
                            </div>
                            <div>
                                <x-input-label for="end_level" :value="__("Bitiş Seviyesi")" />
                                <x-text-input id="end_level" class="block mt-1 w-full dark:bg-gray-700 dark:text-white" type="number" name="end_level" :value="old("end_level", $server->end_level)" required min="1" />
                                <x-input-error :messages="$errors->get("end_level")" class="mt-2" />
                            </div>
                        </div>

                         <!-- Features -->
                        <div class="mb-4">
                            <x-input-label for="features" :value="__("Özellikler (Virgülle ayırın, opsiyonel)")" />
                            <x-text-input id="features" class="block mt-1 w-full dark:bg-gray-700 dark:text-white" type="text" name="features" :value="old("features", $server->features)" placeholder="Örn: Lycan, Kuşak Sistemi, Simya" />
                            <x-input-error :messages="$errors->get("features")" class="mt-2" />
                        </div>

                        <!-- Opening Date -->
                        <div class="mb-4">
                            <x-input-label for="opening_date" :value="__("Açılış Tarihi")" />
                            <x-text-input id="opening_date" class="block mt-1 w-full dark:bg-gray-700 dark:text-white" type="date" name="opening_date" :value="old("opening_date", $server->opening_date ? $server->opening_date->format("Y-m-d") : null)" required />
                            <x-input-error :messages="$errors->get("opening_date")" class="mt-2" />
                        </div>

                        <!-- Links -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <x-input-label for="site_link" :value="__("Site Linki")" />
                                <x-text-input id="site_link" class="block mt-1 w-full dark:bg-gray-700 dark:text-white" type="url" name="site_link" :value="old("site_link", $server->site_link)" required placeholder="https://example.com" />
                                <x-input-error :messages="$errors->get("site_link")" class="mt-2" />
                            </div>
                            <div>
                                <x-input-label for="discord_link" :value="__("Discord Linki (Opsiyonel)")" />
                                <x-text-input id="discord_link" class="block mt-1 w-full dark:bg-gray-700 dark:text-white" type="url" name="discord_link" :value="old("discord_link", $server->discord_link)" placeholder="https://discord.gg/example" />
                                <x-input-error :messages="$errors->get("discord_link")" class="mt-2" />
                            </div>
                        </div>

                        <!-- Cover Image -->
                        <div class="mb-4">
                            <x-input-label for="cover_image" :value="__("Kapak Görseli (Değiştirmek için seçin, opsiyonel)")" />
                             @if($server->cover_image_path)
                            <div class="mt-2 mb-2">
                                <img src="{{ Storage::url($server->cover_image_path) }}" alt="Mevcut Kapak" class="h-20 object-contain rounded-md">
                            </div>
                            @endif
                            <input id="cover_image" name="cover_image" type="file" class="block w-full text-sm text-gray-500 dark:text-gray-400
                                file:me-4 file:py-2 file:px-4
                                file:rounded-lg file:border-0
                                file:text-sm file:font-semibold
                                file:bg-custom-red file:text-white
                                hover:file:bg-red-700
                                file:disabled:opacity-50 file:disabled:pointer-events-none
                                dark:file:bg-red-700
                                dark:hover:file:bg-red-600
                            ">
                            <x-input-error :messages="$errors->get("cover_image")" class="mt-2" />
                            <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">PNG, JPG, GIF (Max 2MB).</p>
                        </div>

                        <div class="flex items-center justify-end mt-6">
                            <a href="{{ route("profile.servers") }}" class="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-md text-sm font-medium mr-2">
                                İptal
                            </a>
                            <x-primary-button class="bg-custom-red hover:bg-red-700 focus:bg-red-700 active:bg-red-800 focus:ring-red-500">
                                {{ __("Sunucuyu Güncelle") }}
                            </x-primary-button>
                        </div>
                    </form>

                    {{-- Delete Server Button --}}
                    <div class="mt-8 border-t dark:border-gray-700 pt-6">
                         <h3 class="text-lg font-medium text-red-600 dark:text-red-400">Sunucuyu Sil</h3>
                         <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">Bu işlem geri alınamaz. Sunucunuzu silmek istediğinizden emin misiniz?</p>
                         <form method="POST" action="{{ route("servers.destroy", $server) }}" class="mt-4" onsubmit="return confirm("Bu sunucuyu kalıcı olarak silmek istediğinizden emin misiniz?");">
                            @csrf
                            @method("DELETE")
                            <x-danger-button>
                                {{ __("Sunucuyu Sil") }}
                            </x-danger-button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>

