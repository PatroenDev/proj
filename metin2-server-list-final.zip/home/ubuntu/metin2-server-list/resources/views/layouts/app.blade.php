<!DOCTYPE html>
<html lang="{{ str_replace("_", "-", app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        {{-- SEO Başlık ve Açıklama - Dinamik olarak doldurulacak --}}
        <title>{{ $title ?? config("app.name", "Laravel") }}</title>
        <meta name="description" content="{{ $description ?? "Metin2 Private Sunucu Listesi - En iyi pvp serverları keşfedin!" }}">

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        {{-- Metin2 Teması için Fontlar --}}
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=MedievalSharp&family=Lato:wght@400;700&display=swap" rel="stylesheet">

        <!-- Scripts -->
        @vite(["resources/css/app.css", "resources/js/app.js"])

        {{-- Toastr CSS --}}
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    </head>
    {{-- Temaya uygun arkaplan ve genel font ayarı --}}
    <body class="font-lato antialiased bg-gray-200 dark:bg-gradient-to-b dark:from-gray-900 dark:to-gray-800">
        <div class="min-h-screen">
            @include("layouts.navigation")

            <!-- Page Heading -->
            @if (isset($header))
                {{-- Başlık için farklı arkaplan ve font --}}
                <header class="bg-white dark:bg-gray-800/80 shadow backdrop-blur-sm">
                    <div class="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8">
                        {{ $header }}
                    </div>
                </header>
            @endif

            <!-- Page Content -->
            <main>
                {{ $slot }}
            </main>
        </div>

        {{-- jQuery ve Toastr JS --}}
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

        {{-- Toastr Bildirimleri --}}
        <script>
            @if(Session::has("success"))
                toastr.success("{{ Session::get("success") }}");
            @endif
            @if(Session::has("error"))
                toastr.error("{{ Session::get("error") }}");
            @endif
            @if(Session::has("info"))
                toastr.info("{{ Session::get("info") }}");
            @endif
            @if(Session::has("warning"))
                toastr.warning("{{ Session::get("warning") }}");
            @endif
        </script>
    </body>
</html>

