<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Banner;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;

class BannerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(): View
    {
        $banners = Banner::latest()->paginate(10); // Paginate results
        return view("admin.banners.index", compact("banners"));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(): View
    {
        return view("admin.banners.create");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            "image" => "required|image|mimes:jpeg,png,jpg,gif,svg|max:2048",
            "link" => "nullable|url|max:255",
            "position" => "required|in:top,left,right",
            "expires_at" => "nullable|date",
        ]);

        $imagePath = $request->file("image")->store("public/banners");

        Banner::create([
            "image_path" => $imagePath,
            "link" => $validated["link"],
            "position" => $validated["position"],
            "expires_at" => $validated["expires_at"],
        ]);

        return redirect()->route("admin.banners.index")->with("success", "Banner başarıyla oluşturuldu.");
    }

    /**
     * Display the specified resource.
     */
    public function show(Banner $banner)
    {
        // Typically not needed for admin CRUD, redirect to edit or index
        return redirect()->route("admin.banners.edit", $banner);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Banner $banner): View
    {
        return view("admin.banners.edit", compact("banner"));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Banner $banner): RedirectResponse
    {
        $validated = $request->validate([
            "image" => "nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048", // Image is optional on update
            "link" => "nullable|url|max:255",
            "position" => "required|in:top,left,right",
            "expires_at" => "nullable|date",
        ]);

        $updateData = [
            "link" => $validated["link"],
            "position" => $validated["position"],
            "expires_at" => $validated["expires_at"],
        ];

        if ($request->hasFile("image")) {
            // Delete old image
            Storage::delete($banner->image_path);
            // Store new image
            $updateData["image_path"] = $request->file("image")->store("public/banners");
        }

        $banner->update($updateData);

        return redirect()->route("admin.banners.index")->with("success", "Banner başarıyla güncellendi.");
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Banner $banner): RedirectResponse
    {
        // Delete the image file first
        Storage::delete($banner->image_path);
        // Delete the banner record
        $banner->delete();

        return redirect()->route("admin.banners.index")->with("success", "Banner başarıyla silindi.");
    }
}

