<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Server;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;

class ServerManagementController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(): View
    {
        // Eager load user relationship to avoid N+1 problem
        $servers = Server::with("user")->latest()->paginate(15);
        return view("admin.servers.index", compact("servers"));
    }

    /**
     * Show the form for creating a new resource.
     * Admin doesn't create servers, users do. Redirect to index.
     */
    public function create(): RedirectResponse
    {
        return redirect()->route("admin.servers.index");
    }

    /**
     * Store a newly created resource in storage.
     * Admin doesn't create servers, users do. Redirect to index.
     */
    public function store(Request $request): RedirectResponse
    {
        return redirect()->route("admin.servers.index");
    }

    /**
     * Display the specified resource.
     * Redirect to edit view.
     */
    public function show(Server $server): RedirectResponse
    {
        return redirect()->route("admin.servers.edit", $server);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Server $server): View
    {
        // Eager load user relationship
        $server->load("user");
        return view("admin.servers.edit", compact("server"));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Server $server): RedirectResponse
    {
        $validated = $request->validate([
            "name" => "required|string|max:255",
            "short_desc" => "required|string|max:500",
            "category" => "required|in:Orta,Emek,Wslik,Oldschool",
            "start_level" => "required|integer|min:1",
            "end_level" => "required|integer|min:1",
            "features" => "nullable|string|max:1000",
            "opening_date" => "required|date",
            "site_link" => "required|url|max:255",
            "discord_link" => "nullable|url|max:255",
            "cover_image" => "nullable|image|mimes:jpeg,png,jpg,gif|max:2048", // Max 2MB
            "is_approved" => "nullable|boolean",
            "is_vip" => "nullable|boolean",
            "vip_expires_at" => "nullable|date|required_if:is_vip,1",
        ]);

        $updateData = [
            "name" => $validated["name"],
            "short_desc" => $validated["short_desc"],
            "category" => $validated["category"],
            "start_level" => $validated["start_level"],
            "end_level" => $validated["end_level"],
            "features" => $validated["features"],
            "opening_date" => $validated["opening_date"],
            "site_link" => $validated["site_link"],
            "discord_link" => $validated["discord_link"],
            "is_approved" => $request->boolean("is_approved"), // Get boolean value
            "is_vip" => $request->boolean("is_vip"),
            "vip_expires_at" => $request->boolean("is_vip") ? $validated["vip_expires_at"] : null,
        ];

        if ($request->hasFile("cover_image")) {
            // Delete old image if exists
            if ($server->cover_image_path) {
                Storage::delete($server->cover_image_path);
            }
            // Store new image
            $updateData["cover_image_path"] = $request->file("cover_image")->store("public/server_covers");
        }

        $server->update($updateData);

        return redirect()->route("admin.servers.index")->with("success", "Sunucu başarıyla güncellendi.");
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Server $server): RedirectResponse
    {
        // Delete cover image if exists
        if ($server->cover_image_path) {
            Storage::delete($server->cover_image_path);
        }

        // Delete related votes first (optional, depending on cascade settings)
        // $server->votes()->delete();

        $server->delete();

        return redirect()->route("admin.servers.index")->with("success", "Sunucu başarıyla silindi.");
    }

    /**
     * Approve a server.
     */
    public function approve(Server $server): RedirectResponse
    {
        $server->update(["is_approved" => true]);
        return redirect()->route("admin.servers.index")->with("success", "Sunucu ".$server->name." onaylandı.");
    }
}

