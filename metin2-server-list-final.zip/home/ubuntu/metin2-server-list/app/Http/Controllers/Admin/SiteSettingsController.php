<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;

class SiteSettingsController extends Controller
{
    /**
     * Show the form for editing the site settings.
     */
    public function index(): View
    {
        // Fetch all settings or create defaults if they don't exist
        $settings = Setting::pluck("value", "key")->all();

        // Ensure default keys exist
        $defaults = [
            "site_name" => config("app.name", "Laravel"),
            "site_description" => "",
            "logo_path" => null,
            "favicon_path" => null,
        ];

        // Merge defaults with existing settings
        $settings = array_merge($defaults, $settings);

        return view("admin.settings.index", compact("settings"));
    }

    /**
     * Update the site settings in storage.
     */
    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            "site_name" => "required|string|max:255",
            "site_description" => "nullable|string|max:1000",
            "logo" => "nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048", // Max 2MB
            "favicon" => "nullable|image|mimes:png,ico|max:512", // Max 512KB, ico or png
        ]);

        // Update text settings
        Setting::updateOrCreate(["key" => "site_name"], ["value" => $validated["site_name"]]);
        Setting::updateOrCreate(["key" => "site_description"], ["value" => $validated["site_description"]]);

        // Handle Logo Upload
        if ($request->hasFile("logo")) {
            $logoPath = $request->file("logo")->store("public/settings");
            // Delete old logo if exists
            $oldLogo = Setting::where("key", "logo_path")->value("value");
            if ($oldLogo) {
                Storage::delete($oldLogo);
            }
            Setting::updateOrCreate(["key" => "logo_path"], ["value" => $logoPath]);
        }

        // Handle Favicon Upload
        if ($request->hasFile("favicon")) {
            $faviconPath = $request->file("favicon")->store("public/settings");
            // Delete old favicon if exists
            $oldFavicon = Setting::where("key", "favicon_path")->value("value");
            if ($oldFavicon) {
                Storage::delete($oldFavicon);
            }
            Setting::updateOrCreate(["key" => "favicon_path"], ["value" => $faviconPath]);
        }

        // Clear config cache if necessary, especially if settings are used in config files
        // Artisan::call('config:clear');

        return redirect()->route("admin.settings.index")->with("success", "Site ayarları başarıyla güncellendi.");
    }
}

