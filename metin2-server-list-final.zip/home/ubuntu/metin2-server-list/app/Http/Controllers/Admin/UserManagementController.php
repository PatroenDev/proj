<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;

class UserManagementController extends Controller
{
    /**
     * Kullanıcıların listesini gösterir.
     */
    public function index(): View
    {
        // Kullanıcıları en yeniden eskiye doğru sırala ve sayfala
        $users = User::latest()->paginate(15);
        return view("admin.users.index", compact("users"));
    }

    /**
     * Yeni kullanıcı oluşturma formu.
     * Admin doğrudan kullanıcı oluşturmaz, kullanıcılar kendileri kayıt olur.
     */
    public function create(): RedirectResponse
    {
        return redirect()->route("admin.users.index");
    }

    /**
     * Yeni kullanıcı kaydetme.
     * Admin doğrudan kullanıcı oluşturmaz.
     */
    public function store(Request $request): RedirectResponse
    {
        return redirect()->route("admin.users.index");
    }

    /**
     * Belirtilen kullanıcıyı gösterir.
     * Düzenleme görünümüne yönlendirir.
     */
    public function show(User $user): RedirectResponse
    {
        return redirect()->route("admin.users.edit", $user);
    }

    /**
     * Belirtilen kullanıcıyı düzenleme formunu gösterir.
     */
    public function edit(User $user): View
    {
        return view("admin.users.edit", compact("user"));
    }

    /**
     * Belirtilen kullanıcıyı günceller.
     * Yönetici durumunu ve yasaklanma durumunu değiştirmek için kullanılır.
     */
    public function update(Request $request, User $user): RedirectResponse
    {
        // İlk kullanıcıyı (ID 1) veya mevcut giriş yapmış admini değiştirmeyi engelle
        if ($user->id === 1) {
            return redirect()->route("admin.users.index")->with("error", "İlk kullanıcı değiştirilemez.");
        }

        $validated = $request->validate([
            "is_admin" => "nullable|boolean",
            "is_banned" => "nullable|boolean", // Banlama özelliği için doğrulama eklendi
        ]);

        $updateData = [
            "is_admin" => $request->boolean("is_admin"),
            "is_banned" => $request->boolean("is_banned"), // Banlama özelliği eklendi
        ];

        // Mevcut giriş yapmış adminin kendi admin yetkisini veya ban durumunu kaldıramamasını sağla
        if (Auth::id() === $user->id) {
            if (!$updateData["is_admin"]) {
                return redirect()->route("admin.users.edit", $user)->with("error", "Kendi admin yetkinizi kaldıramazsınız.");
            }
            // Adminin kendini banlamasını engellemek isteğe bağlıdır, şimdilik izin veriliyor ama mantıksız olabilir.
            // if ($updateData["is_banned"]) {
            //     return redirect()->route("admin.users.edit", $user)->with("error", "Kendinizi banlayamazsınız.");
            // }
        }

        $user->update($updateData);

        return redirect()->route("admin.users.index")->with("success", "Kullanıcı başarıyla güncellendi.");
    }

    /**
     * Belirtilen kullanıcıyı siler.
     */
    public function destroy(User $user): RedirectResponse
    {
        // İlk kullanıcıyı (ID 1) veya mevcut giriş yapmış admini silmeyi engelle
        if ($user->id === 1 || Auth::id() === $user->id) {
            return redirect()->route("admin.users.index")->with("error", "Bu kullanıcı silinemez.");
        }

        // İsteğe bağlı: İlişkili verileri sil (örn. sunucular, oylar) veya veritabanı kısıtlamaları ile yönet
        // $user->servers()->delete();
        // $user->votes()->delete();

        $user->delete();

        return redirect()->route("admin.users.index")->with("success", "Kullanıcı başarıyla silindi.");
    }

    /**
     * Bir kullanıcıyı banlar veya banını kaldırır.
     */
    public function toggleBan(User $user): RedirectResponse
    {
        // İlk kullanıcıyı (ID 1) veya mevcut giriş yapmış admini banlamayı/banını kaldırmayı engelle
        if ($user->id === 1 || Auth::id() === $user->id) {
            return redirect()->route("admin.users.index")->with("error", "Bu kullanıcı banlanamaz veya banı kaldırılamaz.");
        }

        // Ban durumunu tersine çevir
        $user->update(["is_banned" => !$user->is_banned]);

        $message = $user->is_banned ? "Kullanıcı başarıyla banlandı." : "Kullanıcının banı başarıyla kaldırıldı.";
        return redirect()->route("admin.users.index")->with("success", $message);
    }
}

