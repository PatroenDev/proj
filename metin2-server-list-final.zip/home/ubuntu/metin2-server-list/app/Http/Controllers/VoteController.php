<?php

namespace App\Http\Controllers;

use App\Models\Server;
use App\Models\Vote;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\RedirectResponse;
use Carbon\Carbon;

class VoteController extends Controller
{
    /**
     * Yeni bir oyu veritabanına kaydeder.
     * Hem kullanıcı ID'si hem de IP adresi bazında günlük oy limitini kontrol eder.
     *
     * @param Request $request Gelen istek objesi.
     * @param Server $server Oylanacak sunucu modeli.
     * @return RedirectResponse Kullanıcıyı önceki sayfaya yönlendirir ve işlem sonucu hakkında bilgi verir.
     */
    public function store(Request $request, Server $server): RedirectResponse
    {
        $user = Auth::user();
        $ipAddress = $request->ip(); // Kullanıcının IP adresini al
        $today = Carbon::today(); // Bugünün tarihini al

        // Sunucunun onaylı olup olmadığını kontrol et
        if (!$server->is_approved) {
            return back()->with("error", "Bu sunucu henüz onaylanmadı.")->withInput();
        }

        // Kullanıcının bu sunucu için bugün zaten oy verip vermediğini kontrol et
        $existingUserVote = Vote::where("user_id", $user->id)
                                ->where("server_id", $server->id)
                                ->whereDate("voted_at", $today)
                                ->first();

        if ($existingUserVote) {
            return back()->with("error", "Bu sunucu için bugün zaten oy verdiniz.")->withInput();
        }

        // Aynı IP adresinden bu sunucu için bugün zaten oy verilip verilmediğini kontrol et
        $existingIpVote = Vote::where("ip_address", $ipAddress)
                              ->where("server_id", $server->id)
                              ->whereDate("voted_at", $today)
                              ->first();

        // Eğer aynı IP'den oy varsa ve bu oy farklı bir kullanıcıya aitse (veya kullanıcı girişi yapılmamışsa)
        // Veya IP kontrolü genel olarak aktifse (burada aktif kabul ediyoruz)
        if ($existingIpVote) {
             return back()->with("error", "Bu IP adresi ile bugün bu sunucu için zaten oy kullanılmış.")->withInput();
        }


        // Yeni oy kaydını oluştur
        Vote::create([
            "user_id" => $user->id,
            "server_id" => $server->id,
            "ip_address" => $ipAddress, // IP adresini kaydet
            "voted_at" => now(),
        ]);

        // Sunucunun oy sayısını artır
        $server->increment("vote_count");

        // Başarı mesajı ile geri yönlendir
        return back()->with("success", "Oyunuz başarıyla kaydedildi!");
    }
}

