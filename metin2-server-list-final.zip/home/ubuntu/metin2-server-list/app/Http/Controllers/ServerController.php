<?php

namespace App\Http\Controllers;

use App\Models\Server;
use App\Models\Banner; // Banner modelini ekle
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;

class ServerController extends Controller
{
    /**
     * Onaylanmış sunucuları ve aktif bannerları listeler.
     *
     * @return View Sunucu listesi ve bannerları içeren view dosyasını döndürür.
     */
    public function index(): View
    {
        // Onaylanmış sunucuları getir, önce VIP sonra oy sayısına göre sırala
        $servers = Server::where("is_approved", true)
                         ->orderByDesc("is_vip")
                         ->orderByDesc("vote_count")
                         ->paginate(10); // Sayfalama sayısını ihtiyaca göre ayarla

        // Aktif ve süresi dolmamış bannerları pozisyonlarına göre getir
        $now = now();
        $topBanner = Banner::where("position", "top")
                           ->where("is_active", true)
                           ->where(function ($query) use ($now) {
                               $query->whereNull("expires_at")->orWhere("expires_at", ">", $now);
                           })
                           ->orderBy("order", "asc") // İsteğe bağlı: Sıralama ekle
                           ->first();

        $leftBanners = Banner::where("position", "left")
                             ->where("is_active", true)
                             ->where(function ($query) use ($now) {
                                 $query->whereNull("expires_at")->orWhere("expires_at", ">", $now);
                             })
                             ->orderBy("order", "asc") // İsteğe bağlı: Sıralama ekle
                             ->get();

        $rightBanners = Banner::where("position", "right")
                              ->where("is_active", true)
                              ->where(function ($query) use ($now) {
                                  $query->whereNull("expires_at")->orWhere("expires_at", ">", $now);
                              })
                              ->orderBy("order", "asc") // İsteğe bağlı: Sıralama ekle
                              ->get();

        // Sunucuları ve bannerları view'a gönder
        return view("servers.index", compact("servers", "topBanner", "leftBanners", "rightBanners"));
    }

    /**
     * Yeni sunucu oluşturma formunu gösterir.
     */
    public function create(): View
    {
        return view("servers.create");
    }

    /**
     * Yeni oluşturulan sunucuyu veritabanına kaydeder.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            "name" => "required|string|max:255|unique:servers,name",
            "short_desc" => "required|string|max:500",
            "category" => "required|in:Orta,Emek,Wslik,Oldschool",
            "start_level" => "required|integer|min:1",
            "end_level" => "required|integer|min:1|gte:start_level",
            "features" => "nullable|string|max:1000",
            "opening_date" => "required|date",
            "site_link" => "required|url|max:255",
            "discord_link" => "nullable|url|max:255",
            "cover_image" => "nullable|image|mimes:jpeg,png,jpg,gif|max:2048", // Max 2MB
        ]);

        $serverData = $validated;
        $serverData["user_id"] = Auth::id();
        $serverData["is_approved"] = false; // Sunucular varsayılan olarak onay bekler
        $serverData["vote_count"] = 0;

        if ($request->hasFile("cover_image")) {
            // public diskini kullanarak dosyayı sakla ve yolunu al
            $path = $request->file("cover_image")->store("server_covers", "public");
            $serverData["cover_image_path"] = $path;
        }

        Server::create($serverData);

        // Kullanıcının sunucu listesine veya başarı sayfasına yönlendir
        return redirect()->route("profile.servers")->with("success", "Sunucunuz başarıyla eklendi ve onay bekliyor.");
    }

    /**
     * Belirtilen sunucuyu gösterir.
     */
    public function show(Server $server): View|RedirectResponse
    {
        // Sadece onaylı sunucuları herkese, kendi sunucusunu sahibine veya tüm sunucuları admine göster
        if (!$server->is_approved && !(Auth::check() && (Auth::id() === $server->user_id || Auth::user()->is_admin))) {
            abort(404);
        }
        $server->load("user"); // Kullanıcı ilişkisini yükle
        return view("servers.show", compact("server"));
    }

    /**
     * Belirtilen sunucuyu düzenleme formunu gösterir.
     * Sadece sahibi veya admin düzenleyebilir.
     */
    public function edit(Server $server): View|RedirectResponse
    {
        // Giriş yapmış kullanıcının sahip veya admin olup olmadığını kontrol et
        if (Auth::id() !== $server->user_id && !(Auth::check() && Auth::user()->is_admin)) {
            abort(403, "Bu sunucuyu düzenleme yetkiniz yok.");
        }
        return view("servers.edit", compact("server"));
    }

    /**
     * Belirtilen sunucuyu veritabanında günceller.
     * Sadece sahibi veya admin güncelleyebilir.
     */
    public function update(Request $request, Server $server): RedirectResponse
    {
        // Giriş yapmış kullanıcının sahip veya admin olup olmadığını kontrol et
        if (Auth::id() !== $server->user_id && !(Auth::check() && Auth::user()->is_admin)) {
            abort(403, "Bu sunucuyu güncelleme yetkiniz yok.");
        }

        $validated = $request->validate([
            "name" => "required|string|max:255|unique:servers,name,".$server->id,
            "short_desc" => "required|string|max:500",
            "category" => "required|in:Orta,Emek,Wslik,Oldschool",
            "start_level" => "required|integer|min:1",
            "end_level" => "required|integer|min:1|gte:start_level",
            "features" => "nullable|string|max:1000",
            "opening_date" => "required|date",
            "site_link" => "required|url|max:255",
            "discord_link" => "nullable|url|max:255",
            "cover_image" => "nullable|image|mimes:jpeg,png,jpg,gif|max:2048", // Max 2MB
        ]);

        $updateData = $validated;

        if ($request->hasFile("cover_image")) {
            // Eski görsel varsa sil
            if ($server->cover_image_path) {
                Storage::disk("public")->delete($server->cover_image_path);
            }
            // Yeni görseli sakla
            $path = $request->file("cover_image")->store("server_covers", "public");
            $updateData["cover_image_path"] = $path;
        }

        // Eğer admin olmayan bir kullanıcı düzenleme yaparsa, onay durumunu sıfırla
        if (Auth::check() && !Auth::user()->is_admin) {
            $updateData["is_approved"] = false;
        }

        $server->update($updateData);

        $message = "Sunucu başarıyla güncellendi.";
        if (Auth::check() && !Auth::user()->is_admin) {
            $message .= " Tekrar onaylanması gerekiyor.";
        }

        // Kimin düzenlediğine göre yönlendir
        $redirectRoute = (Auth::check() && Auth::user()->is_admin) ? "admin.servers.index" : "profile.servers";

        return redirect()->route($redirectRoute)->with("success", $message);
    }

    /**
     * Belirtilen sunucuyu veritabanından kaldırır.
     * Sadece sahibi veya admin silebilir.
     */
    public function destroy(Server $server): RedirectResponse
    {
        // Giriş yapmış kullanıcının sahip veya admin olup olmadığını kontrol et
        if (Auth::id() !== $server->user_id && !(Auth::check() && Auth::user()->is_admin)) {
            abort(403, "Bu sunucuyu silme yetkiniz yok.");
        }

        // Kapak görseli varsa sil
        if ($server->cover_image_path) {
            Storage::disk("public")->delete($server->cover_image_path);
        }

        // İlişkili oyları sil (Model eventleri daha temiz olabilir)
        $server->votes()->delete();

        $server->delete();

        // Kimin sildiğine göre yönlendir
        $redirectRoute = (Auth::check() && Auth::user()->is_admin) ? "admin.servers.index" : "profile.servers";

        return redirect()->route($redirectRoute)->with("success", "Sunucu başarıyla silindi.");
    }
}

