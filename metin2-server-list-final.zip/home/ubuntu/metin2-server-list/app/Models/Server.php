<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Server extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        "user_id",
        "name",
        "short_desc",
        "category",
        "start_level",
        "end_level",
        "features",
        "opening_date",
        "site_link",
        "discord_link",
        "cover_image_path",
        "is_approved",
        "is_vip",
        "vip_expires_at",
        "vote_count",
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        "opening_date" => "date",
        "is_approved" => "boolean",
        "is_vip" => "boolean",
        "vip_expires_at" => "datetime",
    ];

    /**
     * Get the user that owns the server.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the votes for the server.
     */
    public function votes(): HasMany
    {
        return $this->hasMany(Vote::class);
    }
}

