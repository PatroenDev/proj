<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     * Kitle olarak atanabilir öznitelikler.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        "name",
        "email",
        "password",
        "is_admin", // Yönetici durumu
        "is_banned", // Yasaklanma durumu
    ];

    /**
     * The attributes that should be hidden for serialization.
     * Serileştirme için gizlenmesi gereken öznitelikler.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        "password",
        "remember_token",
    ];

    /**
     * The attributes that should be cast.
     * Tür dönüşümü yapılması gereken öznitelikler.
     *
     * @var array<string, string>
     */
    protected $casts = [
        "email_verified_at" => "datetime",
        "password" => "hashed",
        "is_admin" => "boolean", // boolean olarak cast et
        "is_banned" => "boolean", // boolean olarak cast et
    ];

    /**
     * Get the servers added by the user.
     * Kullanıcının eklediği sunucuları getirir.
     */
    public function servers(): HasMany
    {
        return $this->hasMany(Server::class);
    }

    /**
     * Get the votes cast by the user.
     * Kullanıcının verdiği oyları getirir.
     */
    public function votes(): HasMany
    {
        return $this->hasMany(Vote::class);
    }
}

